/*
Language: DOS .bat
Author: Alexander Makarov (http://rmcreative.ru/)
*/

function(hljs) {
  return {
    case_insensitive: true,
    defaultMode: {
      keywords: {
        flow: 'if else goto for in do call exit not exist errorlevel defined equ neq lss leq gtr geq',
        keyword: 'shift cd dir echo setlocal endlocal set pause copy',
        stream: 'prn nul lpt3 lpt2 lpt1 con com4 com3 com2 com1 aux',
        winutils: 'ping net ipconfig taskkill xcopy ren del'
      },
      contains: [
        {
          className: 'envvar', begin: '%%[^ ]'
        },
        {
          className: 'envvar', begin: '%[^ ]+?%'
        },
        {
          className: 'envvar', begin: '![^ ]+?!'
        },
        {
          className: 'number', begin: '\\b\\d+',
          relevance: 0
        },
        {
          className: 'comment',
          begin: '@?rem', end: '$'
        }
      ]
    }
  };
}
