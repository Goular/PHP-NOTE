/*
Language: VHDL
Author: Igor Kalnitsky <igor@kalnitsky.org>
Contributors: Daniel C.K. Kho <daniel.kho@gmail.com>
Description: VHDL is a hardware description language used in electronic design automation to describe digital and mixed-signal systems.
*/

function(hljs) {
  return {
    case_insensitive: true,
    defaultMode: {
      keywords: {
        keyword:
          'abs access after alias all and architecture array assert attribute begin block ' +
          'body buffer bus case component configuration constant context cover disconnect ' +
          'downto default else elsif end entity exit fairness file for force function generate ' +
          'generic group guarded if impure in inertial inout is label library linkage literal ' +
          'loop map mod nand new next nor not null of on open or others out package port ' +
          'postponed procedure process property protected pure range record register reject ' +
          'release rem report restrict restrict_guarantee return rol ror select sequence ' +
          'severity shared signal sla sll sra srl strong subtype then to transport type ' +
          'unaffected units until use variable vmode vprop vunit wait when while with xnor xor',
        typename:
          'boolean bit character severity_level integer time delay_length natural positive ' +
          'string bit_vector file_open_kind file_open_status std_ulogic std_ulogic_vector ' +
          'std_logic std_logic_vector unsigned signed boolean_vector integer_vector ' +
          'real_vector time_vector'
      },
      illegal: '{',
      contains: [
        hljs.C_BLOCK_COMMENT_MODE,        // VHDL-2008 block commenting.
        {
          className: 'comment',
          begin: '--', end: '$'
        },
        hljs.QUOTE_STRING_MODE,
        hljs.C_NUMBER_MODE,
        {
          className: 'literal',
          begin: '\'(U|X|0|1|Z|W|L|H|-)\'',
          contains: [hljs.BACKSLASH_ESCAPE]
        },
        {
          className: 'attribute',
          begin: '\'[A-Za-z](_?[A-Za-z0-9])*',
          contains: [hljs.BACKSLASH_ESCAPE]
        }
      ]
    } // defaultMode
  } // return;
}
